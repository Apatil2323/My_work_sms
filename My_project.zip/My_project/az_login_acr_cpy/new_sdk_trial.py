from azure.identity import ClientSecretCredential
from azure.mgmt.containerregistry import ContainerRegistryManagementClient

# Azure credentials
tenant_id = "6b5bd02b-92d2-40b2-9ffd-c9c94280c757"
client_id = "68779e77-82af-4951-ab64-97c44639ba57"
client_secret = "V~W8Q~zhCKIZzBstwGopwTJvsk6B6FCC2xLxua9X"
subscription_id = "ff0d97ee-5b28-4dd2-9562-8d4f20d71154"

# ACR details
source_acr_name = "xiotxpcdevcr"
source_acr_resource_group = "xiotglobal-cr-rg"
target_acr_name = "xiotvpccertcr"
target_acr_resource_group = "xiotglobal-cr-rg"
repository_name = "Myapp"
image_tag = "watcher-crd7"

# Create a credential object
credential = ClientSecretCredential(tenant_id, client_id, client_secret)

# Create a client
client = ContainerRegistryManagementClient(credential, subscription_id)

# Function to import an image from the source ACR to the target ACR
def import_image(source_acr, source_acr_rg, target_acr, target_acr_rg, repo, tag):
    try:
        # Define the source image
        source_image = f"{source_acr}.azurecr.io/{repo}:{tag}"

        # Define the import parameters
        import_parameters = {
            'source': {
                'source_image': source_image,
                 'ResourceId'
                'registry': {
                    'login_server': f"{source_acr}.azurecr.io",
                    'username': None,
                    'password': None
                }
            },
            'target_tags': [f"{repo}:{tag}"],
            'mode': 'Force'
        }

        # Import the image
        result = client.registries.begin_import_image(
            resource_group_name=target_acr_rg,
            registry_name=target_acr,
            parameters=import_parameters
        )

        # Wait for the operation to complete
        result.wait()
        print(f"Image imported successfully: {source_image} -> {target_acr}.azurecr.io/{repo}:{tag}")

    except Exception as e:
        print(f"Failed to import image: {e}")

# Import the image from the source ACR to the target ACR
import_image(source_acr_name, source_acr_resource_group, target_acr_name, target_acr_resource_group, repository_name, image_tag)

