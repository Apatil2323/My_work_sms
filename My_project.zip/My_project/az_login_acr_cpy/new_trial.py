from kubernetes import client, config, watch
import subprocess
import time
import json
import requests


tenant_id = "6b5bd02b-92d2-40b2-9ffd-c9c94280c757"
client_id = "68779e77-82af-4951-ab64-97c44d639ba57"
client_secret = "V~W8Q~zhCKIZzBstwGopwTJvsk6B6FCC2xLxua9X"
source_acr_name = "xiotxpcdevcr"
target_acr_name = "xiotvpccertcr"

def get_access_token():
    try:
        url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
        payload = {
            'grant_type': 'client_credentials',
            'client_id': client_id,
            'client_secret': client_secret,
            'resource': 'https://management.azure.com/'
        }
        response = requests.post(url, data=payload)
        response.raise_for_status()
        access_token = response.json().get('access_token')
        return access_token
    except requests.exceptions.RequestException as e:
        print(f"Failed to get access token: {e}")
        return None

def get_latest_resource_version(apps_v1):
    try:
        deployments = apps_v1.list_deployment_for_all_namespaces(watch=False)
        return deployments.metadata.resource_version
    except Exception as e:
        print(f"Failed to get latest resource version: {e}")
        return ""

def transfer_image(source_acr, target_acr, repo, tag, access_token):
    try:
        source_image = f"{source_acr}.azurecr.io/{repo}:{tag}"
        target_image = f"{target_acr}.azurecr.io/{repo}:{tag}"

        # Construct the command to execute
        command = [
            "az", "acr", "import",
            "--name", target_acr,
            "--source", source_image,
            "--image", f"{repo}:{tag}"
        ]

        # Set the environment variable for the access token
        env = {
            'AZURE_ACCESS_TOKEN': access_token
        }

        # Execute the command
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
        stdout, stderr = process.communicate()

        if process.returncode != 0:
            print(f"Failed to transfer image: {stderr.decode('utf-8')}")
        else:
            print(f"Image transferred successfully: {source_image} -> {target_image}")

    except Exception as e:
        print(f"Failed to transfer image {source_image} to {target_image}: {e}")

def main():
    try:
        # Load Kubernetes config (in-cluster configuration)
        config.load_incluster_config()

        # Initialize Kubernetes API client
        apps_v1 = client.AppsV1Api()

        # Get the latest resource version to avoid processing historical events
        resource_version = get_latest_resource_version(apps_v1)

        # Watch for deployment events
        w = watch.Watch()

        print("Starting to watch for Deployment events...")

        # Main event loop
        while True:
            try:
                for event in w.stream(apps_v1.list_deployment_for_all_namespaces, resource_version=resource_version):
                    event_type = event['type']
                    deployment = event['object']
                    deployment_name = deployment.metadata.name
                    namespace = deployment.metadata.namespace

                    resource_version = deployment.metadata.resource_version

                    if namespace == 'kube-system':
                        continue

                    if event_type in ['ADDED', 'MODIFIED']:
                        containers = deployment.spec.template.spec.containers
                        for container in containers:
                            image_path = container.image
                            print(f"Event: {event_type} Deployment: {deployment_name} Namespace: {namespace}")
                            print(f"  Image Path: {image_path}")

                            repo, tag = image_path.split('/')[-1].split(':')

                            # Get access token
                            access_token = get_access_token()
                            if access_token:
                                # Transfer image from source ACR to target ACR
                                transfer_image(source_acr_name, target_acr_name, repo, tag, access_token)
                            else:
                                print("Failed to obtain access token. Skipping image transfer.")

            except Exception as e:
                print(f"Error in main loop: {e}")
                print("Retrying after 5 seconds...")
                time.sleep(5)

    except Exception as e:
        print(f"Initialization failed: {e}")

if __name__ == '__main__':
    main()
