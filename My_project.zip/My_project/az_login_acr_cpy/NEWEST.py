import subprocess
import json

# Destination ACR name
dest_acrname = "xiotvpccertcr"

# Source ACR name and image details
source_acrname = "xiotxpcdevcr"
imagename = "watcher-img-copy7-az"
tag = "latest"

# Construct the full source image URL
source_image = f"{source_acrname}.azurecr.io/{imagename}:{tag}"

# Function to check if the tag exists in the source ACR
def tag_exists(acr_name, repository, tag):
    try:
        # List tags for the repository
        cmd = f"az acr repository show-tags --name {acr_name} --repository {repository} --output json"
        result = subprocess.check_output(cmd, shell=True)
        tags = json.loads(result)
        return tag in tags
    except subprocess.CalledProcessError as e:
        print(f"Failed to list tags for {repository}: {e.output.decode()}")
        return False

# Check if the tag exists
if tag_exists(source_acrname, imagename, tag):
    # Construct the az acr import command
    my_command = f"az acr import --name {dest_acrname} --source {source_image} --image {imagename}:{tag} --force"

    try:
        # Execute the command
        datacmd = subprocess.check_output(my_command, shell=True)
        print(f"Image {source_image} imported successfully to {dest_acrname}.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while importing {source_image}: {e.output.decode()}")
else:
    print(f"Tag {tag} not found in {source_acrname}/{imagename}. Please check the image and tag.")
