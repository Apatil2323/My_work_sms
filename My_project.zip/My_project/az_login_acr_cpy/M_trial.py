import subprocess

# Destination ACR name
dest_acrname = "xiotvpccertcr"

# Source image URL
source_url = "xiotxpcdevcr.azurecr.io"
imagename = "watcher-img-copy8-az"
tag="latest"

# Construct the full source image URL
source_image = f"{source_url}/{imagename}:{tag}"

# Construct the az acr import command
my_command = f"az acr import --name {dest_acrname} --source {source_image} --force"

try:
    # Execute the command
    datacmd = subprocess.check_output(my_command, shell=True)
    print(f"Image {source_image} imported successfully to {dest_acrname}.")
except subprocess.CalledProcessError as e:
    print(f"An error occurred while importing {source_image}: {e.output.decode()}")

