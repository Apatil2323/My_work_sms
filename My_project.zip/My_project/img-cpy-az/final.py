from kubernetes import client, config, watch
import subprocess
import json
import time

# Azure Service Principal credentials
tenant_id = "6b5bd02b-92d2-40b2-9ffd-c9c94280c757"
client_id = "68779e77-82af-4951-ab64-97c44639ba57"
client_secret = "V~W8Q~zhCKIZzBstwGopwTJvsk6B6FCC2xLxua9X"

subscription_id = "ff0d97ee-5b28-4dd2-9562-8d4f20d71154"

# Azure Container Registry details
target_acr = "xiotvpccertcr"

# Function to execute shell command
def execute_command(command):
    try:
        result = subprocess.check_output(command, shell=True)
        return result.decode('utf-8')
    except subprocess.CalledProcessError as e:
        print(f"Command failed: {e.output.decode('utf-8')}")
        return None

# Function to log in to Azure using a service principal
def azure_login(tenant_id, client_id, client_secret):
    login_command = f"az login --service-principal --username {client_id} --password {client_secret} --tenant {tenant_id}"
    execute_command(login_command)
    set_subscription_command = f"az account set -s {subscription_id}"
    execute_command(set_subscription_command)

# Function to check if the tag exists in the ACR
def tag_exists(acr_name, repository, tag):
    try:
        cmd = f"az acr repository show-tags --name {acr_name} --repository {repository} --output json"
        result = execute_command(cmd)
        if result:
            tags = json.loads(result)
            return tag in tags
        return False
    except Exception as e:
        print(f"Failed to list tags for {repository}: {e}")
        return False

# Function to transfer an image from source ACR to target ACR
def transfer_image(source_image, target_acr, repository, tag):
    try:
        cmd = f"az acr import --name {target_acr} --source {source_image} --image {repository}:{tag} --force"
        result = execute_command(cmd)
        if result:
            print(f"Image {source_image} imported successfully to {target_acr}.")
        else:
            print(f"Failed to import image {source_image}.")
    except Exception as e:
        print(f"Failed to import image {source_image}: {e}")

# Function to handle deployment events
def handle_deployment_event(deployment):
    containers = deployment.spec.template.spec.containers
    for container in containers:
        image_path = container.image
        print(f"  Image Path: {image_path}")

        # Parse the image path into registry, repository, and tag
        registry, repository, tag = parse_image_path(image_path)

        # Ensure Azure login before proceeding
        azure_login(tenant_id, client_id, client_secret)

        # Check if tag exists in target ACR
        if tag_exists(target_acr, repository, tag):
            print(f"Tag {tag} already exists in {target_acr}. Skipping import.")
        else:
            # Transfer the image from source ACR to target ACR
            transfer_image(image_path, target_acr, repository, tag)

# Function to parse image path into registry, repository, and tag
def parse_image_path(image_path):
    # Split the registry from the rest of the path
    registry, remainder = image_path.split('/', 1)
    
    # Split the remainder into repository and tag
    repository, tag = remainder.rsplit(':', 1)
    
    return registry, repository, tag

# Function to get the latest resource version
def get_latest_resource_version(apps_v1):
    # Get the list of all deployments in all namespaces
    deployments = apps_v1.list_deployment_for_all_namespaces(watch=False)
    # Return the resource_version of the latest deployment
    return deployments.metadata.resource_version

def main():
    # Load the kubeconfig file 
    config.load_incluster_config()

    # Define the API client for the AppsV1Api
    apps_v1 = client.AppsV1Api()

    # Get the latest resource version to avoid historical events
    resource_version = get_latest_resource_version(apps_v1)

    # Create a watcher to watch for events related to Deployments
    w = watch.Watch()

    print("Starting to watch for Deployment events...")

    while True:
        try:
            # Watch for deployment events starting from the latest resource version
            for event in w.stream(apps_v1.list_deployment_for_all_namespaces, resource_version=resource_version):
                event_type = event['type']
                deployment = event['object']
                deployment_name = deployment.metadata.name
                namespace = deployment.metadata.namespace

                # Update the resource_version
                resource_version = deployment.metadata.resource_version

                # Skip the 'kube-system' namespace
                if namespace == 'kube-system':    
                    continue
                print(f"Event: {event_type} Deployment: {deployment_name} Namespace: {namespace}")

                if event_type in ['ADDED', 'MODIFIED']:
                    handle_deployment_event(deployment)
                    
        except Exception as e:
            print(f"Error in main loop: {e}")
            print("Retrying after 5 seconds...")
            time.sleep(5)  # Retry after 5 seconds

if __name__ == '__main__':
    main()
